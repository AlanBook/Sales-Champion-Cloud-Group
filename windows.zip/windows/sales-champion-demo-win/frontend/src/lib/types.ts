export type AuthUser = {
  id: string;
  username?: string;
  display_name: string;
  role_code: string;
  store_id?: string | null;
};

export type LoginResponse = {
  access_token: string;
  token_type: string;
  user: AuthUser;
};

export type OverviewResponse = {
  today_reception_count: number;
  today_conversion_count: number;
  today_revenue: number;
  week_reception_count: number;
  week_conversion_rate: number;
  top_staff: Array<{ staff_id: string; name: string; score: number }>;
  top_objections: Array<{ type: string; count: number }>;
};

export type RankingItem = {
  staff_id: string;
  name: string;
  level: string;
  total_score: number;
  dimensions: Record<string, number>;
};

export type ChampionDetail = {
  staff_id: string;
  name: string;
  role_level: string;
  total_score: number;
  dimensions: Record<string, number>;
  radar: Array<{ dimension: string; score: number }>;
  diagnostics: string[];
};

export type QuestionInsight = {
  label: string;
  count: number;
};

export type ObjectionInsight = {
  type: string;
  count: number;
};

export type ProductInsight = {
  product_id: string;
  product_name: string;
  heat: number;
  paid_orders: number;
  low_conversion_risk: boolean;
};

export type TeamWeakness = {
  dimension: string;
  score: number;
  suggestion: string;
};

export type KnowledgeDocument = {
  id: string;
  doc_type: string;
  title: string;
  source_type: string;
  source_ref?: string | null;
  summary: string;
  metadata_json: Record<string, unknown>;
  status: string;
  created_at: string;
  updated_at: string;
};

export type KnowledgeSearchItem = {
  document_id: string;
  chunk_id: string;
  doc_type: string;
  title: string;
  score: number;
  content: string;
  source_ref?: string | null;
};

export type AssistantResult = {
  customer_intent: string;
  scene: string;
  budget_range: string;
  taste_preference: string[];
  recommended_products: Array<{
    product_id: string;
    product_name: string;
    fit_score: number;
    reason_points: string[];
    suggested_pitch: string;
    risk_notes: string[];
  }>;
  recommendation_reasons: string[];
  objection_strategy: {
    type: string;
    logic_points: string[];
    suggested_pitch: string;
  };
  suggested_pitch: string;
  follow_up_questions: string[];
  confidence: number;
  evidence_sources: string[];
};

export type AssistantResponse = {
  session_id: string;
  result: AssistantResult;
};

export type TrainingResult = {
  score: number;
  dimension_scores: Record<string, number>;
  missing_questions: string[];
  improvement_suggestions: string[];
  rewritten_reply: string;
};
