// 页面导航
document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetPage = item.dataset.page;
            
            // 更新导航状态
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            // 切换页面
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === targetPage) {
                    page.classList.add('active');
                }
            });
        });
    });

    // 快捷操作按钮
    const quickActions = document.querySelectorAll('.quick-action');
    quickActions.forEach(action => {
        action.addEventListener('click', () => {
            const text = action.textContent;
            const chatInput = document.querySelector('.chat-input');
            chatInput.value = text;
            chatInput.focus();
        });
    });

    // 发送消息
    const sendBtn = document.querySelector('.btn-send');
    const chatInput = document.querySelector('.chat-input');

    function sendMessage() {
        const message = chatInput.value.trim();
        if (!message) return;

        const messagesContainer = document.querySelector('.chat-messages');
        
        // 添加用户消息
        const userMessage = document.createElement('div');
        userMessage.className = 'message user';
        userMessage.innerHTML = `
            <div class="message-avatar">👤</div>
            <div class="message-content">
                <p>${message}</p>
            </div>
        `;
        messagesContainer.appendChild(userMessage);

        // 清空输入框
        chatInput.value = '';

        // 滚动到底部
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        // 模拟 AI 回复
        setTimeout(() => {
            const aiMessage = document.createElement('div');
            aiMessage.className = 'message ai';
            aiMessage.innerHTML = `
                <div class="message-avatar">🤖</div>
                <div class="message-content">
                    <p>收到你的问题了！让我为你分析一下...</p>
                    <p>针对"${message}"，我建议：</p>
                    <ul>
                        <li>先了解客户的核心需求和预算范围</li>
                        <li>根据客户的使用场景推荐 2-3 款产品</li>
                        <li>重点强调产品的独特价值和差异化优势</li>
                        <li>主动提供试饮/试用体验</li>
                    </ul>
                    <p>需要我为你生成具体的推荐话术吗？</p>
                </div>
            `;
            messagesContainer.appendChild(aiMessage);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 1000);
    }

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // 客户卡片跟进按钮
    const followBtns = document.querySelectorAll('.btn-follow');
    followBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const customerCard = btn.closest('.customer-card');
            const customerName = customerCard.querySelector('h3').textContent;
            alert(`即将联系客户：${customerName}\n\n将打开对话窗口，准备跟进话术...`);
        });
    });

    // 话术卡片操作
    const scriptActionBtns = document.querySelectorAll('.script-actions .btn-icon');
    scriptActionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const icon = btn.textContent;
            if (icon === '⭐') {
                btn.style.color = btn.style.color === 'rgb(245, 158, 11)' ? '' : '#f59e0b';
            } else if (icon === '📋') {
                const scriptCard = btn.closest('.script-card');
                const scriptTitle = scriptCard.querySelector('.script-title').textContent;
                navigator.clipboard.writeText(scriptTitle);
                alert('话术标题已复制到剪贴板！');
            } else if (icon === '✏️') {
                alert('打开编辑窗口，可以自定义修改话术内容...');
            }
        });
    });

    // 话术分类筛选
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const category = btn.textContent;
            console.log('筛选分类:', category);
            // 这里可以添加实际的筛选逻辑
        });
    });

    // 图表切换
    const chartTabs = document.querySelectorAll('.chart-tabs .tab');
    chartTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            chartTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const period = tab.textContent;
            console.log('切换图表周期:', period);
            // 这里可以添加实际的图表数据更新逻辑
        });
    });

    // 工具按钮
    const toolBtns = document.querySelectorAll('.tool-btn');
    toolBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const title = btn.getAttribute('title');
            alert(`点击了：${title}\n\n功能开发中...`);
        });
    });

    // 向销冠教练请教按钮
    const learnBtn = document.querySelector('.section-card .btn-primary');
    if (learnBtn) {
        learnBtn.addEventListener('click', () => {
            // 切换到教练页面
            navItems.forEach(nav => {
                nav.classList.remove('active');
                if (nav.dataset.page === 'coach') {
                    nav.classList.add('active');
                }
            });
            
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === 'coach') {
                    page.classList.add('active');
                }
            });

            // 预填充问题
            setTimeout(() => {
                chatInput.value = '如何提高高价产品的推荐成功率？';
            }, 300);
        });
    }

    // 客户卡片操作按钮
    const customerActionBtns = document.querySelectorAll('.customer-action .btn-icon');
    customerActionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const icon = btn.textContent;
            const customerCard = btn.closest('.customer-card');
            const customerName = customerCard.querySelector('h3').textContent;
            
            if (icon === '💬') {
                alert(`即将与客户 ${customerName} 发起对话\n\n将打开智能对话助手...`);
            } else if (icon === '📝') {
                alert(`编辑客户 ${customerName} 的档案信息\n\n可以更新客户偏好、购买记录等...`);
            }
        });
    });

    // 提升建议中的"立即学习"按钮
    const suggestionBtns = document.querySelectorAll('.suggestion-item .btn-link');
    suggestionBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const suggestionItem = btn.closest('.suggestion-item');
            const suggestionTitle = suggestionItem.querySelector('h4').textContent;
            
            // 切换到话术库页面
            navItems.forEach(nav => {
                nav.classList.remove('active');
                if (nav.dataset.page === 'scripts') {
                    nav.classList.add('active');
                }
            });
            
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === 'scripts') {
                    page.classList.add('active');
                }
            });

            console.log('学习主题:', suggestionTitle);
        });
    });
});

// 模拟数据更新
function updateMetrics() {
    // 这里可以添加实际的 API 调用，更新业绩数据
    console.log('更新业绩数据...');
}

// 定时刷新（可选）
// setInterval(updateMetrics, 60000); // 每分钟刷新一次
